package com.zainsudan.freevpn.data

import android.content.Context
import android.provider.Settings
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.wireguard.crypto.KeyPair
import java.security.MessageDigest

class CryptoManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "zain_vpn_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getOrCreateKeyPair(): KeyPair {
        val existingPrivate = prefs.getString("wg_private_key", null)
        if (existingPrivate != null) {
            return KeyPair(com.wireguard.crypto.Key.fromBase64(existingPrivate))
        }
        val newKeyPair = KeyPair()
        prefs.edit()
            .putString("wg_private_key", newKeyPair.privateKey.toBase64())
            .putString("wg_public_key", newKeyPair.publicKey.toBase64())
            .apply()
        return newKeyPair
    }

    fun saveJwtToken(token: String) {
        prefs.edit().putString("jwt_token", token).apply()
    }

    fun getJwtToken(): String? = prefs.getString("jwt_token", null)

    fun getAnonymousDeviceHash(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(androidId.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
