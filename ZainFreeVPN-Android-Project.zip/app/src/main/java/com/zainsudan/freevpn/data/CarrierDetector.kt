package com.zainsudan.freevpn.data

import android.content.Context
import android.telephony.TelephonyManager

data class CarrierInfo(
    val mccMnc: String,
    val operatorName: String,
    val isZainSudan: Boolean
)

object CarrierDetector {
    private const val ZAIN_SUDAN_MCC_MNC = "63401"

    fun detectCarrier(context: Context): CarrierInfo {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val simOp = tm.simOperator.ifEmpty { tm.networkOperator }
        val opName = tm.simOperatorName.ifEmpty { tm.networkOperatorName }.ifEmpty { "Unknown" }
        return CarrierInfo(
            mccMnc = simOp,
            operatorName = opName,
            isZainSudan = simOp == ZAIN_SUDAN_MCC_MNC
        )
    }
}
