package com.zainsudan.freevpn

import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.*
import androidx.core.os.LocaleListCompat
import com.zainsudan.freevpn.data.ConnectionState
import com.zainsudan.freevpn.ui.MainScreen
import com.zainsudan.freevpn.ui.VpnViewModel
import com.zainsudan.freevpn.ui.ZainVpnTheme

class MainActivity : ComponentActivity() {

    private val viewModel: VpnViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var darkTheme by remember { mutableStateOf(true) }
            var currentLang by remember { mutableStateOf("en") }
            val state by viewModel.connectionState.collectAsState()

            val vpnPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    viewModel.initiateConnectRequest()
                }
            }

            ZainVpnTheme(darkTheme = darkTheme) {
                MainScreen(
                    viewModel = viewModel,
                    darkTheme = darkTheme,
                    onToggleTheme = { darkTheme = !darkTheme },
                    onToggleLanguage = {
                        currentLang = if (currentLang == "en") "ar" else "en"
                        AppCompatDelegate.setApplicationLocales(
                            LocaleListCompat.forLanguageTags(currentLang)
                        )
                    },
                    onConnectClicked = {
                        if (state == ConnectionState.CONNECTED || state == ConnectionState.CONNECTING) {
                            viewModel.disconnectTunnel()
                        } else {
                            val prepareIntent = VpnService.prepare(this)
                            if (prepareIntent != null) {
                                vpnPermissionLauncher.launch(prepareIntent)
                            } else {
                                viewModel.initiateConnectRequest()
                            }
                        }
                    }
                )
            }
        }
    }
}
