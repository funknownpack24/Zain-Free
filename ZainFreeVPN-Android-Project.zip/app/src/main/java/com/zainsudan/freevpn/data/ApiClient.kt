package com.zainsudan.freevpn.data

import com.zainsudan.freevpn.BuildConfig
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface ZainVpnApi {
    @POST("auth/session")
    suspend fun authenticate(@Body request: AuthRequest): AuthResponse

    @GET("servers")
    suspend fun getServers(@Header("Authorization") bearer: String): List<VpnServer>

    @POST("vpn/provision")
    suspend fun provisionTunnel(
        @Header("Authorization") bearer: String,
        @Body request: ProvisionRequest
    ): ProvisionResponse

    @POST("diagnostics/report")
    suspend fun submitDiagnostics(
        @Header("Authorization") bearer: String,
        @Body report: DiagnosticReport
    )
}

object ApiClient {
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    val api: ZainVpnApi by lazy {
        Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ZainVpnApi::class.java)
    }
}
