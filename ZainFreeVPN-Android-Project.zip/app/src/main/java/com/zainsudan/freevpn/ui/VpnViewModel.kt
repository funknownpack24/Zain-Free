package com.zainsudan.freevpn.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zainsudan.freevpn.data.*
import com.zainsudan.freevpn.vpn.ZainVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.InetAddress
import kotlin.system.measureTimeMillis

class VpnViewModel(app: Application) : AndroidViewModel(app) {

    private val crypto = CryptoManager(app)
    val connectionState = ZainVpnService.connectionState
    val rxBytes = ZainVpnService.rxBytes
    val txBytes = ZainVpnService.txBytes
    val logs = ZainVpnService.logs

    private val _servers = MutableStateFlow(
        listOf(
            VpnServer("sd-krt-01", "Khartoum Zero-Rated #1", "Sudan", "196.29.160.10:51820", "j9T+Z8p2L4v8N0x1Q2w3E4r5T6y7U8i9O0p1A2s3D4g=", 28, 34, true),
            VpnServer("sd-pzu-02", "Port Sudan Edge #2", "Sudan", "196.29.162.44:51820", "k8U+A9q3M5w9O1y2R3x4F5s6U7z8V9j0P1q2B3t4E5h=", 41, 48, true),
            VpnServer("de-fra-01", "Frankfurt Transit #1", "Germany", "185.220.101.5:51820", "m7V+B0r4N6x0P2z3S4y5G6t7V8a9W0k1Q2r3C4u5F6i=", 19, 112, false)
        )
    )
    val servers: StateFlow<List<VpnServer>> = _servers

    private val _selectedServer = MutableStateFlow<VpnServer?>(null)
    val selectedServer: StateFlow<VpnServer?> = _selectedServer

    private val _isSponsoredVerified = MutableStateFlow(false)
    val isSponsoredVerified: StateFlow<Boolean> = _isSponsoredVerified

    private val _showConsentDialog = MutableStateFlow(false)
    val showConsentDialog: StateFlow<Boolean> = _showConsentDialog

    private val _durationSeconds = MutableStateFlow(0L)
    val durationSeconds: StateFlow<Long> = _durationSeconds

    private val _pingMs = MutableStateFlow(38L)
    val pingMs: StateFlow<Long> = _pingMs

    private val _autoReconnect = MutableStateFlow(true)
    val autoReconnect: StateFlow<Boolean> = _autoReconnect

    private var timerJob: Job? = null

    init {
        val carrier = CarrierDetector.detectCarrier(app)
        ZainVpnService.appendLog("Detected SIM Operator: ${carrier.operatorName} (${carrier.mccMnc})")
        if (!carrier.isZainSudan) {
            ZainVpnService.appendLog("Warning: Non-Zain Sudan SIM detected. Zero-rated profile requires MCC 634 MNC 01.")
        }
        viewModelScope.launch {
            connectionState.collect { state ->
                if (state == ConnectionState.CONNECTED) startDurationTimer() else stopDurationTimer()
            }
        }
    }

    fun selectServer(server: VpnServer?) {
        _selectedServer.value = server
    }

    fun setAutoReconnect(enabled: Boolean) {
        _autoReconnect.value = enabled
    }

    fun initiateConnectRequest() {
        if (!_isSponsoredVerified.value) {
            _showConsentDialog.value = true
        } else {
            connectTunnel()
        }
    }

    fun dismissConsentDialog() {
        _showConsentDialog.value = false
    }

    fun confirmConnectWithStandardData() {
        _showConsentDialog.value = false
        connectTunnel()
    }

    private fun connectTunnel() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val keyPair = crypto.getOrCreateKeyPair()
            val targetServer = _selectedServer.value ?: _servers.value.minByOrNull { it.latencyMs }!!

            var assignedIp = "10.66.66.2/32"
            var serverEndpoint = targetServer.endpoint
            var serverPubKey = targetServer.publicKey

            try {
                ZainVpnService.appendLog("Authenticating with Zain Partner API...")
                val carrier = CarrierDetector.detectCarrier(app)
                val authResp = ApiClient.api.authenticate(
                    AuthRequest(crypto.getAnonymousDeviceHash(app), carrier.mccMnc, keyPair.publicKey.toBase64())
                )
                crypto.saveJwtToken(authResp.token)
                _isSponsoredVerified.value = authResp.sponsoredStatus.isSponsoredActive

                val prov = ApiClient.api.provisionTunnel(
                    "Bearer ${authResp.token}",
                    ProvisionRequest(targetServer.id, keyPair.publicKey.toBase64())
                )
                assignedIp = prov.assignedIpIpv4
                serverEndpoint = prov.serverEndpoint
                serverPubKey = prov.serverPublicKey
            } catch (e: Exception) {
                ZainVpnService.appendLog("Control plane unreachable (${e.javaClass.simpleName}); using cached node config.")
            }

            val intent = Intent(app, ZainVpnService::class.java).apply {
                action = ZainVpnService.ACTION_CONNECT
                putExtra("assignedIpv4", assignedIp)
                putExtra("serverEndpoint", serverEndpoint)
                putExtra("serverPubKey", serverPubKey)
                putExtra("clientPrivKey", keyPair.privateKey.toBase64())
                putExtra("mtu", 1280)
                putExtra("autoReconnect", _autoReconnect.value)
            }
            app.startForegroundService(intent)
        }
    }

    fun disconnectTunnel() {
        val app = getApplication<Application>()
        val intent = Intent(app, ZainVpnService::class.java).apply {
            action = ZainVpnService.ACTION_DISCONNECT
        }
        app.startService(intent)
    }

    fun runDiagnostics() {
        viewModelScope.launch(Dispatchers.IO) {
            ZainVpnService.appendLog("Running network & DNS diagnostics...")
            val latency = measureTimeMillis {
                try {
                    InetAddress.getByName("one.one.one.one")
                } catch (_: Exception) {}
            }
            _pingMs.value = latency
            ZainVpnService.appendLog("DNS Lookup Latency: ${latency}ms | Recommended MTU: 1280 bytes")
        }
    }

    private fun startDurationTimer() {
        timerJob?.cancel()
        _durationSeconds.value = 0
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                _durationSeconds.value += 1
            }
        }
    }

    private fun stopDurationTimer() {
        timerJob?.cancel()
        _durationSeconds.value = 0
    }
}
