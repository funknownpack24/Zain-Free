package com.zainsudan.freevpn.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ZainPink = Color(0xFFE91E63)
val ZainPinkLight = Color(0xFFF48FB1)
val DarkNavyBg = Color(0xFF0F0F1A)
val DarkCardSurface = Color(0xFF1B1B2F)
val LightBg = Color(0xFFF8F9FA)
val LightCardSurface = Color(0xFFFFFFFF)

private val DarkColorPalette = darkColorScheme(
    primary = ZainPink,
    secondary = ZainPinkLight,
    background = DarkNavyBg,
    surface = DarkCardSurface,
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColorPalette = lightColorScheme(
    primary = ZainPink,
    secondary = ZainPinkLight,
    background = LightBg,
    surface = LightCardSurface,
    onPrimary = Color.White,
    onBackground = Color(0xFF121212),
    onSurface = Color(0xFF121212)
)

@Composable
fun ZainVpnTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorPalette else LightColorPalette,
        content = content
    )
}
