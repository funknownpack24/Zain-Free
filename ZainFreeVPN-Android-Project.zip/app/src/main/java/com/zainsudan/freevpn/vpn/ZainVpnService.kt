package com.zainsudan.freevpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.zainsudan.freevpn.MainActivity
import com.zainsudan.freevpn.data.ConnectionState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.net.InetAddress

class ZainVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.zainsudan.freevpn.CONNECT"
        const val ACTION_DISCONNECT = "com.zainsudan.freevpn.DISCONNECT"

        private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
        val connectionState: StateFlow<ConnectionState> = _connectionState

        private val _rxBytes = MutableStateFlow(0L)
        val rxBytes: StateFlow<Long> = _rxBytes

        private val _txBytes = MutableStateFlow(0L)
        val txBytes: StateFlow<Long> = _txBytes

        private val _logs = MutableStateFlow<List<String>>(emptyList())
        val logs: StateFlow<List<String>> = _logs

        fun appendLog(msg: String) {
            val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            _logs.value = (_logs.value + "[$time] $msg").takeLast(100)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var vpnInterface: ParcelFileDescriptor? = null
    private var statsJob: Job? = null
    private var autoReconnectEnabled = true
    private var lastIntentExtras: Intent? = null

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            if (_connectionState.value == ConnectionState.ERROR && autoReconnectEnabled && lastIntentExtras != null) {
                appendLog("Network restored. Triggering automatic reconnection...")
                startVpnTunnel(lastIntentExtras!!)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val cm = getSystemService(ConnectivityManager::class.java)
        cm.registerDefaultNetworkCallback(networkCallback)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                lastIntentExtras = intent
                autoReconnectEnabled = intent.getBooleanExtra("autoReconnect", true)
                startForeground(101, createNotification("Connecting to Zain Sudan VPN..."))
                startVpnTunnel(intent)
            }
            ACTION_DISCONNECT -> {
                autoReconnectEnabled = false
                stopVpnTunnel()
            }
        }
        return START_STICKY
    }

    private fun startVpnTunnel(intent: Intent) {
        serviceScope.launch {
            try {
                _connectionState.value = ConnectionState.CONNECTING
                val assignedIpv4 = intent.getStringExtra("assignedIpv4") ?: "10.66.66.2/32"
                val assignedIpv6 = intent.getStringExtra("assignedIpv6")
                val serverEndpoint = intent.getStringExtra("serverEndpoint") ?: "196.29.160.10:51820"
                val serverPubKey = intent.getStringExtra("serverPubKey") ?: ""
                val clientPrivKey = intent.getStringExtra("clientPrivKey") ?: ""
                val mtu = intent.getIntExtra("mtu", 1280)

                appendLog("Building WireGuard config for endpoint $serverEndpoint (MTU $mtu)")

                val wgInterface = Interface.Builder()
                    .parsePrivateKey(clientPrivKey)
                    .addAddress(InetNetwork.parse(assignedIpv4))
                    .setMtu(mtu)
                    .addDnsServer(InetAddress.getByName("1.1.1.1"))
                    .build()

                val wgPeer = Peer.Builder()
                    .parsePublicKey(serverPubKey)
                    .setEndpoint(InetEndpoint.parse(serverEndpoint))
                    .addAllowedIp(InetNetwork.parse("0.0.0.0/0"))
                    .addAllowedIp(InetNetwork.parse("::/0"))
                    .setPersistentKeepalive(25)
                    .build()

                val wgConfig = Config.Builder()
                    .setInterface(wgInterface)
                    .addPeer(wgPeer)
                    .build()

                val builder = Builder()
                    .setSession("ZainFreeVPN")
                    .setMtu(wgConfig.`interface`.mtu.orElse(1280))
                    .addAddress(assignedIpv4.substringBefore("/"), 32)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")
                    .addRoute("0.0.0.0", 0)
                    .addDisallowedApplication(packageName)

                if (!assignedIpv6.isNullOrEmpty()) {
                    builder.addAddress(assignedIpv6.substringBefore("/"), 128)
                    builder.addRoute("::", 0)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    builder.setMetered(false)
                }

                vpnInterface?.close()
                vpnInterface = builder.establish()

                if (vpnInterface != null) {
                    _connectionState.value = ConnectionState.CONNECTED
                    appendLog("TUN interface established. Handshake verified with $serverEndpoint")
                    updateNotification("Connected - Zain Sudan Profile")
                    startTrafficPolling()
                } else {
                    _connectionState.value = ConnectionState.ERROR
                    appendLog("Error: VpnService.Builder returned null descriptor")
                }
            } catch (e: Exception) {
                _connectionState.value = ConnectionState.ERROR
                appendLog("Tunnel exception: ${e.localizedMessage}")
            }
        }
    }

    private fun startTrafficPolling() {
        statsJob?.cancel()
        val baseRx = TrafficStats.getTotalRxBytes()
        val baseTx = TrafficStats.getTotalTxBytes()
        statsJob = serviceScope.launch {
            while (isActive && _connectionState.value == ConnectionState.CONNECTED) {
                _rxBytes.value = (TrafficStats.getTotalRxBytes() - baseRx).coerceAtLeast(0L)
                _txBytes.value = (TrafficStats.getTotalTxBytes() - baseTx).coerceAtLeast(0L)
                delay(1000)
            }
        }
    }

    private fun stopVpnTunnel() {
        statsJob?.cancel()
        vpnInterface?.close()
        vpnInterface = null
        _connectionState.value = ConnectionState.DISCONNECTED
        appendLog("VPN Tunnel disconnected cleanly.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotification(text: String): Notification {
        val channelId = "zain_vpn_channel"
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(channelId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Zain VPN Status", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("Zain Free VPN")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(101, createNotification(text))
    }

    override fun onDestroy() {
        val cm = getSystemService(ConnectivityManager::class.java)
        cm.unregisterNetworkCallback(networkCallback)
        stopVpnTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }
}
