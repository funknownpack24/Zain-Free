package com.zainsudan.freevpn.data

data class VpnServer(
    val id: String,
    val name: String,
    val region: String,
    val endpoint: String,
    val publicKey: String,
    val loadPercent: Int,
    val latencyMs: Int,
    val isZeroRatedCandidate: Boolean
)

data class AuthRequest(
    val deviceIdHash: String,
    val simOperatorMccMnc: String,
    val clientPublicKey: String
)

data class AuthResponse(
    val token: String,
    val expiresAt: Long,
    val sponsoredStatus: SponsoredStatus
)

data class SponsoredStatus(
    val isSponsoredActive: Boolean,
    val carrierName: String,
    val quotaRemainingMb: Int,
    val noticeMessage: String
)

data class ProvisionRequest(
    val serverId: String,
    val clientPublicKey: String
)

data class ProvisionResponse(
    val assignedIpIpv4: String,
    val assignedIpIpv6: String?,
    val dnsServers: List<String>,
    val serverPublicKey: String,
    val serverEndpoint: String,
    val allowedIps: List<String>,
    val persistentKeepalive: Int,
    val mtu: Int,
    val isZeroRatedVerified: Boolean
)

data class DiagnosticReport(
    val simMccMnc: String,
    val isZainSudanSim: Boolean,
    val apiReachable: Boolean,
    val dnsLatencyMs: Long,
    val mtuSafeSize: Int,
    val timestamp: String
)

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR
}
