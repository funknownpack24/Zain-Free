package com.zainsudan.freevpn.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zainsudan.freevpn.R
import com.zainsudan.freevpn.data.ConnectionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: VpnViewModel,
    darkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onToggleLanguage: () -> Unit,
    onConnectClicked: () -> Unit
) {
    val state by viewModel.connectionState.collectAsState()
    val rxBytes by viewModel.rxBytes.collectAsState()
    val txBytes by viewModel.txBytes.collectAsState()
    val duration by viewModel.durationSeconds.collectAsState()
    val ping by viewModel.pingMs.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val servers by viewModel.servers.collectAsState()
    val selectedServer by viewModel.selectedServer.collectAsState()
    val isSponsored by viewModel.isSponsoredVerified.collectAsState()
    val showConsent by viewModel.showConsentDialog.collectAsState()
    val autoReconnect by viewModel.autoReconnect.collectAsState()

    var serverMenuExpanded by remember { mutableStateOf(false) }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissConsentDialog() },
            title = { Text(stringResource(R.string.consent_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.consent_body)) },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmConnectWithStandardData() },
                    colors = ButtonDefaults.buttonColors(containerColor = ZainPink)
                ) {
                    Text(stringResource(R.string.proceed))
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissConsentDialog() }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = ZainPink)
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.app_name), fontWeight = FontWeight.ExtraBold)
                    }
                },
                actions = {
                    IconButton(onClick = onToggleLanguage) {
                        Icon(Icons.Default.Language, contentDescription = "Language")
                    }
                    IconButton(onClick = onToggleTheme) {
                        Icon(
                            if (darkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Theme"
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSponsored) Color(0xFF1B5E20) else Color(0xFFB71C1C).copy(alpha = 0.85f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = stringResource(R.string.carrier_profile),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = if (isSponsored) stringResource(R.string.sponsored_verified)
                        else stringResource(R.string.sponsored_unverified),
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            val pulseAnim = rememberInfiniteTransition(label = "pulse")
            val scale by pulseAnim.animateFloat(
                initialValue = 1f,
                targetValue = if (state == ConnectionState.CONNECTING) 1.08f else 1f,
                animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
                label = "scale"
            )

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(170.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (state == ConnectionState.CONNECTED)
                                listOf(ZainPink, Color(0xFF880E4F))
                            else
                                listOf(ZainPink.copy(alpha = 0.7f), Color(0xFF37001F))
                        )
                    )
                    .border(4.dp, ZainPinkLight, CircleShape)
                    .clickable { onConnectClicked() }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Power",
                        tint = Color.White,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = when (state) {
                            ConnectionState.CONNECTED -> stringResource(R.string.status_connected)
                            ConnectionState.CONNECTING -> stringResource(R.string.status_connecting)
                            else -> stringResource(R.string.status_disconnected)
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = formatDuration(duration),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TelemetryCard(stringResource(R.string.download), formatBytes(rxBytes), Modifier.weight(1f))
                TelemetryCard(stringResource(R.string.upload), formatBytes(txBytes), Modifier.weight(1f))
                TelemetryCard(stringResource(R.string.ping), "${ping} ms", Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))

            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { serverMenuExpanded = true },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, tint = ZainPink)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.select_server), fontSize = 11.sp, color = Color.Gray)
                            Text(
                                selectedServer?.name ?: stringResource(R.string.auto_server),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }

                DropdownMenu(
                    expanded = serverMenuExpanded,
                    onDismissRequest = { serverMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.auto_server)) },
                        onClick = {
                            viewModel.selectServer(null)
                            serverMenuExpanded = false
                        }
                    )
                    servers.forEach { server ->
                        DropdownMenuItem(
                            text = { Text("${server.name} (${server.latencyMs}ms)") },
                            onClick = {
                                viewModel.selectServer(server)
                                serverMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = autoReconnect,
                        onCheckedChange = { viewModel.setAutoReconnect(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = ZainPink)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.auto_reconnect), fontSize = 12.sp)
                }
                TextButton(onClick = { viewModel.runDiagnostics() }) {
                    Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = ZainPink)
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.run_diagnostics), color = ZainPink, fontSize = 12.sp)
                }
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(bottom = 12.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        stringResource(R.string.logs_title),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ZainPink
                    )
                    Spacer(Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(logs) { line ->
                            Text(
                                text = line,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TelemetryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(12.dp)) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 10.sp, color = ZainPink, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

private fun formatBytes(bytes: Long): String {
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return if (mb >= 1.0) "%.2f MB".format(mb) else "%.1f KB".format(kb)
}

private fun formatDuration(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
